//
//  ViewController.swift
//  tracker
//
//  Created by Changtong Zhou on 7/20/16.
//  Copyright © 2016 Changtong Zhou. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var myMapView: MKMapView!
    
    @IBOutlet weak var lbLocation: UILabel!
    
    let myLocMgr = CLLocationManager()
    var myPosition = CLLocationCoordinate2D()
    
    @IBAction func startGPS(sender: AnyObject) {
        myLocMgr.startUpdatingLocation()
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myLocMgr.desiredAccuracy = kCLLocationAccuracyBest
        myLocMgr.requestWhenInUseAuthorization()
        myLocMgr.startUpdatingLocation()
        myLocMgr.delegate = self
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func locationManager(manager: CLLocationManager, didUpdateToLocation newLocation: CLLocation, fromLocation oldLocation: CLLocation) {
        
        print("Got Location \(newLocation.coordinate.latitude) , \(newLocation.coordinate.longitude)")
        
        myPosition = newLocation.coordinate
        
//        myLocMgr.stopUpdatingLocation()
        let lat = newLocation.coordinate.latitude
        let lng = newLocation.coordinate.longitude
        
        lbLocation.text = "\(lat) , \(lng)"
        
        
        let span = MKCoordinateSpanMake(0.20, 0.20)
//        let span = MKCoordinateSpanMake(3.0, 3.0)
        
        let region = MKCoordinateRegion(center: newLocation.coordinate, span: span)
        myMapView.setRegion(region, animated: true)
        
        let myCoor2D = CLLocationCoordinate2D(latitude:lat, longitude:lng)
        
        let annotation = MKPointAnnotation()
        
        annotation.coordinate = myCoor2D
        annotation.title = "Current location"
        annotation.subtitle = "Location of store"
        
        myMapView.addAnnotation(annotation)
        
        myLocMgr.stopUpdatingLocation()
        
    }

    @IBAction func addPin(sender: UILongPressGestureRecognizer) {
        print("llllllllllllllllllllllll")

        let location = sender.locationInView(self.myMapView)
        
        let locCoord = self.myMapView.convertPoint(location, toCoordinateFromView: self.myMapView)
        
        let annotation = MKPointAnnotation()
        
        annotation.coordinate = locCoord
        
        annotation.title = "Pin the location"
        annotation.subtitle = "Location of the place"
    
//        self.myMapView.removeAnnotations(myMapView.annotations)
        self.myMapView.addAnnotation(annotation)
    }
    

    
    
//    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        
//        // get most recent coordinate
//        let myCoor = locations[locations.count-1]
//        
//        // get lat and longit
//        let lat = myCoor.coordinate.latitude
//        let lng = myCoor.coordinate.longitude
//        let myCoor2D = CLLocationCoordinate2D(latitude: lat, longitude: lng)
//        
//        // set span
//        let latData = 0.05
//        let lngData = 0.05
//        let mySpan = MKCoordinateSpan(latitudeDelta: latData, longitudeDelta: lngData)
//        
//        let myRegion = MKCoordinateRegion(center: myCoor2D, span: mySpan)
//        
//        // center map at this region
//        myMapView.setRegion(myRegion, animated: true)
//        
//        // add annotation
//        let myAnno = MKPointAnnotation()
//        myAnno.coordinate = myCoor2D
//        myMapView.addAnnotation(myAnno)
//        
//        //test and see how things look
//    }
    
    

}


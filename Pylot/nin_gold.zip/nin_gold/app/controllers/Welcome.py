
from system.core.controller import *
import random
import string
import datetime

class Welcome(Controller):
    def __init__(self, action):
        super(Welcome, self).__init__(action)
   
    def index(self):
        # session.clear()
        # session['gold'] = 0
        # return self.load_view('index.html')
        # session['gold'] = 0
        # session['tracker'] = ['nothing']
        # session['color'] = []
        try:
            session['gold'] = session['gold']
            session['tracker'] = session['tracker']
            session['color'] = session['color']
        except KeyError:
            session['gold'] = 0
            session['tracker'] = ['nothing']
            session['color'] = []
        print session['color']
        return self.load_view('index.html', tracked=session['tracker'], colors = session['color'])

    def process_money(self):
        if (request.form['gold_type'] == 'farm'):
            earned = int(random.randrange(10, 20))
            session['gold'] += earned
            logStr = "Earned " + str(earned) + " from the farm! " + str(datetime.datetime.now())
            session['tracker'].insert(0, logStr)
            session['color'].insert(0, "green")
        elif (request.form['gold_type']  == 'cave'):
            earned = int(random.randrange(5, 10))
            session['gold'] += earned
            logStr = "Earned " + str(earned) + " from the cave! " + str(datetime.datetime.now())
            session['tracker'].insert(0, logStr)
            session['color'].insert(0, "green")
        elif (request.form['gold_type'] == 'house'):
            earned = int(random.randrange(2, 5))
            session['gold'] += earned
            logStr = "Earned " + str(earned) + " from the house! " + str(datetime.datetime.now())
            session['tracker'].insert(0, logStr)
            session['color'].insert(0, "green")
        elif (request.form['gold_type'] == 'casino'):
            earned = int(random.randrange(-50, 50))
            session['gold'] += earned
            if earned < 0:
                logStr = "Earned " + str(earned) + " from the casino! Ouch. " + str(datetime.datetime.now())
                session['color'].insert(0, "red")
            elif earned >= 0:
                logStr = "Earned " + str(earned) + " from the casino! " + str(datetime.datetime.now())
                session['color'].insert(0, "green")
            session['tracker'].insert(0,logStr)
        return redirect('/')


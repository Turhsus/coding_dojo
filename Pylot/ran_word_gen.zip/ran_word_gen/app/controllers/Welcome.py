"""
    Sample Controller File

    A Controller should be in charge of responding to a request.
    Load models to interact with the database and load views to render them to the client.

    Create a controller using this template
"""
from system.core.controller import *
import string
import random

class Welcome(Controller):
    def __init__(self, action):
        super(Welcome, self).__init__(action)
   
    def index(self):
        try:
            return self.load_view('index.html', attempt = session['attempt'], randomNum = session['random'] )
        except KeyError:
            session['random'] = "No number generated"
            return self.load_view('index.html', attempt = session['attempt'], randomNum = session['random'] )
        

    def generate(self):
        session['attempt'] += 1
        randomLetters = ""
        for i in range(14):
            randomLetters = randomLetters + random.choice(string.letters)
        session['random'] = randomLetters
        return redirect('/')


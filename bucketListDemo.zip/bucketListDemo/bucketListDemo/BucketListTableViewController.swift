//
//  ViewController.swift
//  bucketListDemo
//
//  Created by Pariece Mckinney on 7/14/16.
//  Copyright © 2016 pariece. All rights reserved.
//

import UIKit

class BucketListTableViewController: UITableViewController, CancelDelegate, DoneDelegate {
    var list = ["go out of the country","eat candy"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("missionCell")!
        cell.textLabel?.text = list[indexPath.row]
        return cell
    }
    
    func cancelButtonPressed(controller: UIViewController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func didFinishAddingMission(controller:UIViewController,mission:String){
        list.append(mission)
        tableView.reloadData()
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func didFinishEditingMission(controller: UIViewController, mission: String, index: Int) {
        list[index] = mission
        tableView.reloadData()
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        list.removeAtIndex(indexPath.row)
        tableView.reloadData()
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "addMission" {
            let navController = segue.destinationViewController as! UINavigationController
            let missionController = navController.topViewController as! MissionDetailsViewController
            
            missionController.cancelDelegate = self
            missionController.doneDelegate = self
        }else {
            let navController = segue.destinationViewController as! UINavigationController
            let missionController = navController.topViewController as! MissionDetailsViewController
            
            missionController.cancelDelegate = self
            missionController.doneDelegate = self
            
            
            if let indexPath = tableView.indexPathForCell(sender as! UITableViewCell){
                missionController.missionToEdit = list[indexPath.row]
                missionController.indexOfMissionToEdit = indexPath.row
            }
            
        }
    }

}


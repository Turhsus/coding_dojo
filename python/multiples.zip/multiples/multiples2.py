for count in range(5, 1000000):
	if count % 5 == 0:
		print count

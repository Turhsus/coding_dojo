//
//  Tile.swift
//  cookie_crush
//
//  Created by Tianyu Ying on 7/10/16.
//  Copyright © 2016 Tianyu Ying. All rights reserved.
//

import Foundation

class Tile {
    
}
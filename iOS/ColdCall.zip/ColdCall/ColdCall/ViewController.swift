//
//  ViewController.swift
//  ColdCall
//
//  Created by Sushrut Athavale on 7/6/16.
//  Copyright © 2016 Sushrut Athavale. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
  var names = ["Adam", "Calvin", "Nicole", "JD", "Soumya"]

  @IBOutlet weak var nameLabel: UILabel!
  
  @IBAction func callButtonPress(sender: UIButton) {
    generateName()
  }
  override func viewDidLoad() {
    super.viewDidLoad()
    generateName()
    // Do any additional setup after loading the view, typically from a nib.
  }
  
  func generateName() {
    let index = Int(arc4random_uniform(5))
    print(index)
    nameLabel.text = names[index]
  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }


}


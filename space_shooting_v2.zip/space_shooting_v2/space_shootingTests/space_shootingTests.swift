//
//  space_shootingTests.swift
//  space_shootingTests
//
//  Created by Tianyu Ying on 7/15/16.
//  Copyright © 2016 Tianyu Ying. All rights reserved.
//

import XCTest
@testable import space_shooting

class space_shootingTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
}
